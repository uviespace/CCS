All rights reserved.
Description: # For editing and handling the access to the configuration file
        
        Build the Python package using the makefile.
        Install the Python package using the makefile.
        
        You can use
        [Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
        to write your content.
Platform: UNKNOWN
Classifier: Programming Language :: Python :: 3
Classifier: License
Classifier: Operating System
Description-Content-Type: text/markdown
